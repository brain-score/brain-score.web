from django.apps import AppConfig


class BenchmarksConfig(AppConfig):
    name = 'benchmarks'
